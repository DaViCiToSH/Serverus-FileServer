Serverus FileServer (Apaxy MOD)
# Read this for Mods:
# http://apache.org/docs/2.2/mod/mod_autoindex.html

Just COPY the "serverus" directory into your Document Root, and put file into. Enjoy !!!
********
You can help by donating any amount in cryptocurrency:
********************************************************
Bitcoin:=> bc1qfl6wn5ychfxep6zs8qmrnvkv62964knpa96pj7
 
BNB: => bnb1flhh3t62d08w2qdd7xwx9ku9x3fnxmqjldysy6

TRX: => THgt4vTAaVic8iN1FgN2CdqxjaaVn9vHzr 

USDT(trc20): => THgt4vTAaVic8iN1FgN2CdqxjaaVn9vHzr 

Doge: => DMEVauRdRbC29YNwTDpZm9YSjqngwX7D2e

ETH: => 0xf9aef8Dd0da4F8FA8d615b7b40f2aCa70b40fA99
 
LTC: => ltc1qtekmyz6tq0hnkdhetwgdr5my8uhzu7v4pdymwn
 
Matic: => 0xf9aef8Dd0da4F8FA8d615b7b40f2aCa70b40fA99